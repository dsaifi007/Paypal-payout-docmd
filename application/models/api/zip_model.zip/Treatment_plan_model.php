<?php

class Treatment_plan_model extends CI_Model
{
	private $dollar_symbol = "$";
	
	function __construct()
	{
		parent::__construct();
	}
	public function get_all_treatment_plan()
	{
		$this->db->select("*")->from( $this->config->item("treatment_table") );
		$query=$this->db->get();
		$result = $query->result_array();
		foreach ($result as $key => $value) {
			if ($value['is_recommended'] == $this->config->item("is_recommended")) {
				$val = true;
			}else{
				$val= false;
			}
			$result[$key]['amount'] = $this->dollar_symbol.$value['amount'];
			$result[$key]['is_recommended'] = $val;
		}
		return $result;
	}
}

?>