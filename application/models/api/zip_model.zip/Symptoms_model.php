<?php
/*
class name : Symptoms_model
*/

class Symptoms_model extends CI_Model {

  	function __construct() {
        parent::__construct();
    }
    /*
    --------------------------------------------------------------------------------------------
	|							Get all symptoms 
	--------------------------------------------------------------------------------------------
    */
    public function get_all_symptoms_model()
    {
    	$query = $this->db->select("*")
    			->from($this->config->item("symptoms_table"))
    			->get();
    	return $query->result_array();		
    }
    /*
    --------------------------------------------------------------------------------------------
	|						   Get all Severity Symptoms
	--------------------------------------------------------------------------------------------
	*/
    public function get_all_severity_symptoms_model()
    {
    	$query = $this->db->select("*")
    			->from($this->config->item("severity_symptoms_table"))
    			->get();
    	return $query->result_array();
    }
}

?>