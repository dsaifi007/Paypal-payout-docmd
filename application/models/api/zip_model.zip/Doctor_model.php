<?php

/*
  |-------------------------------------------------------------------------------
  |  All Users information get/set/save/delete
  |-------------------------------------------------------------------------------
 */

class Doctor_model extends CI_Model {

    private $doctor_table = "doctors";
    private $doc_professional_info_table = "doc_professional_info";
    private $professional_info = "doc_professional_info";
    private $address_table = "address";
    private $doctor_address_mapping = "doctor_address";
    protected $degree_table = "doctor_degree";
    protected $speciality = "spacility";
    private $array = [];
    private $is_boolean;
    private $otp_table = "user_otp";

    function __construct() {
        parent::__construct();
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will check the email and phone number existance in DB
      |-------------------------------------------------------------------------------------------------------------------------------
     */

    public function check_email_phone_existance($em, $phone) {
        $this->db->where("email", $em)->or_where("phone", $phone);
        $query = $this->db->select("email,phone")->from($this->doctor_table)->get();
        return ($query->num_rows() > 0) ? true : false;
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will insert the user info and get particular data of inserted users
      |-------------------------------------------------------------------------------------------------------------------------------
     */

    public function create_doctor_account_data_insert($post_data = []) {
        $this->db->where("email", $post_data['email'])->or_where("phone", $post_data['phone']);
        $query = $this->db->select("email,phone")->from($this->doctor_table)->get();
        if ($query->num_rows() == 0) {
            $post_data['password'] = md5($post_data['password']);
            $post_data['access_token'] = getaccessToken();
            $this->db->insert($this->doctor_table, form_input_filter($post_data));
            $id = $this->db->insert_id();

            $this->db->where("id", $id);
            $query = $this->db->select("id,email,phone,access_token,is_email_verified,is_phone_verified,is_blocked")
                            ->from($this->doctor_table)->get();
            $row = $query->row_array();
            $this->array['is_email_verified'] = ($row['is_email_verified'] == 0) ? false : true;
            $this->array['is_phone_verified'] = ($row['is_phone_verified'] == 0) ? false : true;
            $this->array['is_blocked'] = ($row['is_blocked'] == 0 ) ? false : true;
            return array_merge($row, $this->array);
        } else {
            return false;
        }
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will insert address and address mapping data based on doctor id
      |-------------------------------------------------------------------------------------------------------------------------------
     */

    public function doctor_address_inserted($doc_address, $doc_id) {
        $this->db->insert($this->address_table, $doc_address);
        $address_id = $this->db->insert_id();
        $this->db->insert($this->doctor_address_mapping, ["doctor_id" => $doc_id, 'address_id' => $address_id]);
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will insert doctor professional data based on id
      |-------------------------------------------------------------------------------------------------------------------------------
     */

    public function doctor_professional_info_insert($doctor_professional_data) {
        $this->db->insert($this->professional_info, $doctor_professional_data);
        return $this->db->insert_id();
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will update password based on user id
      |-------------------------------------------------------------------------------------------------------------------------------
     */

    public function update_user_password($user_data) {
        $this->db->reset_query();
        $query = $this->db->get_where($this->doctor_table, ['id' => $user_data['userid']]);
        if ($query->num_rows() > 0) {
            $this->user_pass['password'] = md5($user_data['password']);
            $this->db->where('id', $user_data['userid']);
            $this->db->update($this->doctor_table, $this->user_pass);
            $this->is_boolean = TRUE;
        } else {
            $this->is_boolean = FALSE;
        }
        return $this->is_boolean;
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will insert the basic information of users
      |-------------------------------------------------------------------------------------------------------------------------------
     */

    public function update_doctor_info_model($doctor_data, $id) {
        $this->db->where("id", $id);
        $this->db->update($this->doctor_table, $doctor_data);
        return true;
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will update the profile image of the doctor
      |-------------------------------------------------------------------------------------------------------------------------------
     */

    public function doctor_profile_img_update_model($file_name, $file_url, $doc_id) {
        $this->db->where("id", $doc_id);
        $this->db->update($this->doctor_table, ["profile_url" => $file_url, "profile_image" => $file_name]);
    }

    /*
      |-------------------------------------------------------------------------------------------------------------------------------
      | This Function will get the information of the doctor
      |-------------------------------------------------------------------------------------------------------------------------------
     */
    public function get_doctor_profile($doctor_id) {

        $select_field = "doc_info.id as doctor_id,
                         doc_info.first_name,
                         doc_info.last_name,
                         doc_info.date_of_birth,
                         doc_info.gender as gender ,
                         doc_info.profile_url as profile_image_url ,
                         doc_add.address, doc_add.city AS city ,
                         doc_add.state AS state,doc_add.zip_code,
                         doc_profess.undergraduate_university,
                         doc_profess.medical_school,doc_profess.residency,
                         doc_profess.medical_license_number,
                         doc_profess.additional_info,
                         speciality.name as speciality,
                         degree_table.degree
                         ";
        $this->db->select($select_field)
                ->from("$this->doctor_table as doc_info")
                ->join("$this->doc_professional_info_table as doc_profess", "doc_profess.doctor_id = doc_info.id ", "INNER")
                ->join("$this->doctor_address_mapping as doc_add_map", "doc_add_map.doctor_id = doc_info.id", "INNER")
                ->join("$this->address_table as doc_add", "doc_add.id = doc_add_map.address_id", "INNER")
                ->join("$this->speciality as speciality", "speciality.id = doc_profess.speciality_id", "INNER")
                ->join("$this->degree_table as degree_table", "degree_table.id = doc_profess.degree_id", "INNER")
                ->where("doc_info.id", $doctor_id);
        $query = $this->db->get();
        return count($query->row_array()) > 0 ? $query->row_array() : false;
    }

        // get doctor speciality and degree
    public function get_doct_speciality_and_degree_model()
    {
      $this->db->select("id,name as speciality")
              ->from("$this->speciality");
          $query =  $this->db->get();
          $spl_row = $query->result_array();

      $this->db->select("id,degree")
              ->from("$this->degree_table");
          $deg_query =  $this->db->get();
          $deg_row = $deg_query->result_array();
          return array_merge(["specialities"=>$spl_row],["degrees"=>$deg_row]);
    }
    // add verfication code
    public function email_verification_code($email, $email_encoded) {
        //$this->load->library('encrypt');
        $this->db->where("email", $email);
        $query = $this->db->update($this->doctor_table, ["email_verification_code" => $email_encoded]);
        if ($query) {
            return true;
        }
    }

    // when email verfied by email
    public function email_verified($email) {
        $query = $this->db->get_where($this->doctor_table, ['email' => $email]);
        if ($query->num_rows() > 0) {
            $this->db->where("email", $email);
            $this->db->update($this->doctor_table, ["is_email_verified" => $this->config->item("email_verified")]);
            return true;
        } else {
            return false;
        }
    }
    public function store_new_otp($otp_Data) {
        $this->db->insert($this->otp_table, $otp_Data);
    }
    public function get_otp($otp_data) {
        $this->db->where($otp_data);
        $query = $this->db->select("expire_time")
                ->from($this->otp_table)->get();
        return ($query->num_rows() > 0) ? $query->row() :false;
    }
    public function update_otp($doctor_id,$new_otp,$expire_time) {
        $this->db->where("doctor_id",$doctor_id);
        $this->db->update($this->otp_table,["expire_time" => $expire_time,"otp_number" => $new_otp]);
          
        $this->db->where("doctor_id",$doctor_id);
        $query = $this->db->select("otp_number")
                ->from($this->otp_table)->get();
        return $query->row();
    }
   public function delete_otp($doctor_id) {
        $this->db->where("doctor_id",$doctor_id); 
        $this->db->delete($this->otp_table);
    }
    public function check_phone_existance($doctor_id) {
        $this->db->where("id", $doctor_id);
        $query = $this->db->select("phone")->from($this->doctor_table)->get();
        return ($query->num_rows() > 0) ? $query->row() : false;
    }
    public function update_phone_status($doctor_id) {
        $this->db->where("id",$doctor_id);
        $this->db->update($this->doctor_table,["is_phone_verified" => $this->config->item("phone_verified")]);
    }
    public function get_userid($email, $phone) {
        $query = $this->db->get_where($this->doctor_table, ['email' => $email, "phone" => $phone]);
        $row = $query->row_array();
        if (count($row) > 0) {
            return $row['id'];
        }
    }

}

?>