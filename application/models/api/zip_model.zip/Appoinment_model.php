<?php
/*
class name : Appoinment Model
*/

class Appoinment_model extends CI_Model {

    protected $symptoms_array = [];


  	function __construct() {
        parent::__construct();
    }
    /*
    --------------------------------------------------------------------------------------------
	|							Get the Address of the Patient based on Id
	--------------------------------------------------------------------------------------------
    */
    public function get_appointed_doctor_model($patient_id,$specility_id)
    {
        /* We are find the patient state based on patient id */
        $this->db->where("patient_address.patient_id",$patient_id);
    	$this->db->select("address.id,address.state")
    			->from("address");
        $this->db->join("patient_address",'address.id = patient_address.address_id',"INNER");
    	$query = $this->db->get();  
    	$result = $query->row();
        // get appointed doctor
        return $this->get_appointed_doctor_id_model($result->state,$specility_id);		
    }
    /*
    ---------------------------------------------------------------------------------
	| We are finding those doctors, Who have same state with the patient and 
    | specility choose by the patient(Get Appointed Doctor)
    | Basicaly we are appointed the doctor to the user
	---------------------------------------------------------------------------------
	*/
    public function get_appointed_doctor_id_model($state,$spacility_id)
    {
        $this->db->where("spacility.id",$spacility_id);
        $this->db->where("address.state",$state);

    	$query = $this->db->select("doctors.id AS doctor_id")->from("doc_professional_info");
        $this->db->join("doctors",'doctors.id = doc_professional_info.doctor_id',"INNER");
        $this->db->join("spacility",'spacility.id = doc_professional_info.speciality_id',"INNER");
        $this->db->join("doctor_address",'doctor_address.doctor_id = doctors.id',"INNER");
    	$this->db->join("address",'address.id = doctor_address.address_id',"INNER");
        $query = $this->db->get();  
        return count($query->result_array())>0 ? $query->result_array() : false;
    }
    /*
    ---------------------------------------------------------------------------------
    | Insert the appoinment detail in db Table
    ---------------------------------------------------------------------------------
    */
    public function insert_appoinment_detail($data,$appointed_doctor_id)
    {
       $appoinment_data = array_merge([
        "doctor_id"=>$appointed_doctor_id,
        'created_date'=>date("Y-m-d h:i:s")],$data);
       unset($appoinment_data['symptom_ids']);

       // Insert the Appoinment data in table
       $this->db->trans_start();
       $this->db->insert("appointment",$appoinment_data);
       $last_appoinment_id = $this->db->insert_id();
       $this->db->trans_complete();


       // Making the array for mapping the appointment id and symptoms id
       foreach ($data['symptom_ids'] as $key=>$symptom_id) {
           $this->symptoms_array[] = [
            "appointment_id"=>$last_appoinment_id,
            "symptom_id"=>$symptom_id
            ];
       }
       $this->db->insert_batch("appointment_symptom",$this->symptoms_array);
       
       // we are sending the response of API 
       $this->db->where("appointment.id",$last_appoinment_id);
       $this->db->select("
            appointment.id,
            appointment.patient_availability_date AS date,
            appointment.patient_availability_time AS time,
            doc_professional_info.additional_info AS instruction"
        );
       $this->db->from("appointment");
       $this->db->join("doc_professional_info",'doc_professional_info.doctor_id = appointment.doctor_id',"INNER");
       $query = $this->db->get();
       return  $query->row(); // response sent 
    }
}

?>