-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 27, 2018 at 09:49 PM
-- Server version: 5.7.22-0ubuntu0.16.04.1
-- PHP Version: 7.0.28-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `doc_md`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `id` int(10) UNSIGNED NOT NULL,
  `address` tinytext,
  `city` varchar(20) DEFAULT NULL,
  `state` varchar(20) DEFAULT NULL,
  `zip_code` varchar(10) DEFAULT NULL,
  `last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `address`, `city`, `state`, `zip_code`, `last_update`) VALUES
(59, '221/ houston USA', 'Oklahoma City', 'Phoenix', 'abcd1002', '2018-03-11 09:54:44'),
(60, '344/ gzb India', 'Arizona City', 'Prescott', '201003', '2018-03-12 08:16:21'),
(61, '377/ gzb India', 'Jersey City', 'New Jersey', '201003', '2018-03-12 08:18:10'),
(70, '377/2 meerut India', 'Minneapolis', 'Chandler', '201003', '2018-03-14 05:15:14'),
(71, '377  San Francisco', 'Nevada City', 'Arizona', '201003', '2018-03-14 05:16:34'),
(93, 'D.C. 1680 Oaklawn, Post Office Box 12616, Prescott, Arizona 86304', 'Prescott', 'Arizona', '201003', '2018-04-24 09:52:13'),
(94, 'DPT, PRPC. HonorHealth, 9202 N 92nd St. Phoenix, AZ 85020', 'Phoenix', 'Chandler', '201003', '2018-04-24 09:53:12'),
(95, 'P.T. Desert Physical Therapy and Women\'s Health Center, 4545 E. Shea Blvd, Ste. 168, Phoenix', 'Phoenix', 'New Jersey', '201003', '2018-04-24 09:53:12'),
(96, 'P.T. Mountain Valley Regional Rehabilitation Hospital, Inc. 3700 N. Windsong Dr. Prescott Valley, AZ 86314', 'Prescott', 'Prescott', '201003', '2018-04-24 09:53:12'),
(97, 'Desert Spine and Sports Medicine, 3700 North 24th Street, Suite 210, Phoenix, AZ 85016. Phone 602-840-0681', 'Phoenix', 'Phoenix', '201003', '2018-04-24 09:53:12'),
(98, 'W. Chandler Blvd, Suite 31, Chandler, AZ 85224. Phone 480-782-0639, fax 480-786-4761', 'Chandler', 'Chandler', '201003', '2018-04-24 09:53:12');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `admin_id` tinyint(1) UNSIGNED NOT NULL,
  `email` varchar(45) CHARACTER SET utf8 DEFAULT NULL,
  `password` varchar(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=big5 COLLATE=big5_bin;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Stand-in structure for view `all_appointment`
--
CREATE TABLE `all_appointment` (
`patient_id` int(11)
,`doctor_id` int(11)
,`appointment_id` int(11)
,`symptoms` text
,`name` varchar(91)
,`age` bigint(11)
,`gender` varchar(10)
,`patient_availability_date_and_time` datetime
,`type` varchar(30)
,`status` tinyint(3) unsigned
);

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `doc_speciality_id` tinyint(3) UNSIGNED NOT NULL,
  `treatment_provider_plan_id` tinyint(3) UNSIGNED NOT NULL,
  `symptom_start_date` date DEFAULT NULL,
  `severity_of_symptom_id` tinyint(3) UNSIGNED DEFAULT NULL,
  `patient_availability_date_and_time` datetime NOT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '1' COMMENT 'appointment_status',
  `payment_method_id` int(10) UNSIGNED NOT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_update_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `patient_id`, `doctor_id`, `doc_speciality_id`, `treatment_provider_plan_id`, `symptom_start_date`, `severity_of_symptom_id`, `patient_availability_date_and_time`, `status`, `payment_method_id`, `created_date`, `last_update_date`) VALUES
(8, 88, 11, 1, 1, '2018-04-04', 2, '2018-04-27 04:30:00', 1, 1, '2018-04-18 02:30:33', '2018-04-18 09:00:33'),
(13, 77, 11, 1, 1, '2018-02-04', 2, '2018-04-28 10:30:00', 4, 1, '2018-04-23 06:26:00', '2018-04-23 12:56:00'),
(16, 74, 10, 3, 1, '2018-04-04', 2, '2018-04-26 14:30:00', 6, 1, '2018-04-24 03:32:55', '2018-04-24 10:02:55'),
(17, 75, 11, 4, 1, '2018-04-04', 2, '2018-04-20 11:30:00', 6, 1, '2018-04-24 03:36:53', '2018-04-24 10:06:53'),
(26, 76, 12, 5, 1, '2018-04-04', 2, '2018-04-26 11:30:00', 6, 1, '2018-04-24 03:49:32', '2018-04-24 10:19:32'),
(33, 77, 13, 1, 1, '2018-04-04', 2, '2018-04-20 10:30:00', 2, 1, '2018-04-25 01:13:49', '2018-04-25 07:43:49');

-- --------------------------------------------------------

--
-- Table structure for table `appointment_status`
--

CREATE TABLE `appointment_status` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `status` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment_status`
--

INSERT INTO `appointment_status` (`id`, `status`) VALUES
(1, 'Confirmed'),
(2, 'Cancelled by patient'),
(3, 'Cancelled by doctor'),
(4, 'Rescheduled by Patient'),
(5, 'Rescheduled by Doctor'),
(6, 'Completed');

-- --------------------------------------------------------

--
-- Table structure for table `appointment_symptom`
--

CREATE TABLE `appointment_symptom` (
  `appointment_id` int(11) DEFAULT NULL,
  `symptom_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment_symptom`
--

INSERT INTO `appointment_symptom` (`appointment_id`, `symptom_id`) VALUES
(8, 1),
(8, 2),
(8, 3),
(13, 1),
(13, 2),
(13, 3),
(16, 1),
(16, 2),
(16, 3),
(17, 1),
(17, 2),
(17, 3),
(26, 1),
(26, 2),
(26, 3),
(33, 1),
(33, 2),
(33, 3);

-- --------------------------------------------------------

--
-- Table structure for table `consent_care`
--

CREATE TABLE `consent_care` (
  `id` tinyint(1) UNSIGNED NOT NULL,
  `consent_eng_text` text NOT NULL,
  `consent_spn_text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `consent_care`
--

INSERT INTO `consent_care` (`id`, `consent_eng_text`, `consent_spn_text`) VALUES
(1, 'this is english text', 'esto es texto en ingles');

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `content_id` int(11) NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `date_availability_list`
--

CREATE TABLE `date_availability_list` (
  `id` int(11) NOT NULL,
  `date_available` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `date_availability_list`
--

INSERT INTO `date_availability_list` (`id`, `date_available`) VALUES
(1, '2018-04-21'),
(2, '2018-04-28'),
(3, '2018-04-29'),
(4, '2018-04-30'),
(5, '2018-05-01'),
(6, '2018-05-02'),
(7, '2018-05-03'),
(8, '2018-05-04'),
(9, '2018-05-05'),
(10, '2018-05-06'),
(11, '2018-05-07'),
(12, '2018-05-08'),
(13, '2018-05-09'),
(14, '2018-05-10'),
(15, '2018-05-11'),
(16, '2018-05-12'),
(17, '2018-05-13'),
(18, '2018-05-14'),
(19, '2018-05-15'),
(20, '2018-05-16'),
(21, '2018-05-17'),
(22, '2018-05-18'),
(23, '2018-05-19'),
(24, '2018-05-20'),
(25, '2018-05-21'),
(26, '2018-05-22'),
(27, '2018-05-23'),
(28, '2018-05-24'),
(29, '2018-05-25'),
(30, '2018-05-26'),
(31, '2018-05-27');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `access_token` varchar(255) NOT NULL,
  `device_token` varchar(255) DEFAULT NULL,
  `email_verification_code` varchar(255) NOT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `language_id` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `is_email_verified` tinyint(1) DEFAULT '0' COMMENT '0=>block,1=>unblock',
  `is_phone_verified` tinyint(1) NOT NULL DEFAULT '0' COMMENT '0=>block,1=>unblock',
  `is_blocked` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1=>block,0=>unblock',
  `status` enum('pending','accept','reject','') NOT NULL DEFAULT 'pending',
  `profile_url` varchar(80) DEFAULT NULL,
  `profile_image` varchar(35) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `email`, `phone`, `password`, `access_token`, `device_token`, `email_verification_code`, `first_name`, `last_name`, `language_id`, `is_email_verified`, `is_phone_verified`, `is_blocked`, `status`, `profile_url`, `profile_image`, `date_of_birth`, `gender`, `created_date`, `last_update`) VALUES
(1, 'danishk@chromeinfotech.com', '12305078', '25d55ad283aa400af464c76d713c07ad', '294b012fcb0b53c797fc6600702d01ce', '', '', 'danish', 'khan', 1, 0, 0, 1, 'accept', NULL, '', '1992-03-02', 'Male', '2018-03-13 04:27:27', '2018-03-13 06:51:23'),
(9, 'danishmaint1@gmail.com', '123458', 'f2188121aec2cf3974631125174125ad', '294b012fcb0b53c797fc6600702d01ce', '', 'ZGFuaXNobWFpbnRAZ21haWwuY29t', 'harish', 'khan', 2, 1, 1, 0, 'pending', NULL, '', '1998-03-30', 'Female', '2018-03-13 04:23:45', '2018-03-13 07:51:50'),
(10, 'danishmaint12@gmail.com', '12345812', '7794a66176c89870daf95e2120dbcbf5', 'ecfcdfdef1d4a510dded9c77f73ddf2d', '', 'ZGFuaXNobWFpbnRAZ21haWwuY29t', 'tariq', 'khan', 3, 1, 1, 0, 'accept', 'http://localhost/docmd/assets/doctor/profile/1551514902rHLhyFNJ.png', '1551514902rHLhyFNJ.png', '1999-03-30', 'Female', '2018-03-29 06:14:30', '2018-03-13 11:27:58'),
(11, 'danishmaint88@gmail.com', '+14632222411', 'e10adc3949ba59abbe56e057f20f883e', '2d21abf0626e6a11cacbc4a071a59f84', '', 'ZGFuaXNobWFpbnRAZ21haWwuY29t', 'aamir', 'khan', 2, 1, 1, 1, 'accept', NULL, '', '1994-03-30', 'Female', '2018-04-19 03:29:40', '2018-03-14 11:11:12'),
(12, 'danishdoctor@gmail.com', '1234581222', 'f2188121aec2cf3974631125174125ad', '5dd3e3e1d83a297d56bd869b9d473598', NULL, 'ZGFuaXNobWFpbnRAZ21haWwuY29t', 'aamir', 'khan', 2, 0, 0, 1, 'pending', NULL, '', '1991-03-30', 'male', '2018-04-24 03:23:12', '2018-04-24 09:31:53'),
(13, 'danishmaint@gmail.com', '123458122', 'f2188121aec2cf3974631125174125ad', '963d5fa46fd2f35d46075d70807bceda', NULL, 'ZGFuaXNobWFpbnRAZ21haWwuY29t', 'aamir', 'khan', 2, 0, 0, 1, 'pending', NULL, '', '1990-03-30', 'male', '2018-04-24 03:22:13', '2018-04-24 09:32:31');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_address`
--

CREATE TABLE `doctor_address` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `address_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doctor_address`
--

INSERT INTO `doctor_address` (`id`, `doctor_id`, `address_id`) VALUES
(25, 13, 93),
(26, 12, 94),
(27, 11, 95),
(28, 10, 96),
(29, 9, 97),
(30, 1, 98);

-- --------------------------------------------------------

--
-- Table structure for table `doctor_availability_list`
--

CREATE TABLE `doctor_availability_list` (
  `doctor_availability_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `type` enum('daily','weekly','onetime','') NOT NULL,
  `slots` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_availability_list`
--

INSERT INTO `doctor_availability_list` (`doctor_availability_id`, `doctor_id`, `type`, `slots`) VALUES
(1, 10, 'weekly', '[{"day_id":"monday","time_list":[{"from":"11:30:00","to":"12:00:00"},{"from":"12:30:00","to":"01:00:00"},{"from":"09:30:00","to":"10:00:00"}]},{"day_id":"tuesday","time_list":[{"from":"11:30:00","to":"12:00:00"},{"from":"01:00:00","to":"01:30:00"},{"from":"02:30:00","to":"03:00:00"}]}]'),
(2, 9, 'onetime', '{\n	"type":"onetime","doctor_id":10,\n	"slots":{"date":"2018-04-21",\n	"time_list":[{"from":11,"to":22},{"from":11,"to":22},{"from":11,"to":22}]}\n}'),
(3, 12, 'daily', '{"type":"daily","doctor_id":10,"slots":"[{\'time_list\':[{\'from\':11,\'to\':22},{\'from\':11,\'to\':22},{\'from\':11,\'to\':22}]}]"\n}'),
(104, 12, 'onetime', '{"date":"2018-04-21","time_list":[{"from":"10:00:00","to":"11:00:00"},{"from":"11:00:00","to":"12:00:00"},{"from":"14:00:00","to":"15:00:00"}]}');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_degree`
--

CREATE TABLE `doctor_degree` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `degree` varchar(60) NOT NULL,
  `detail` varchar(60) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor_degree`
--

INSERT INTO `doctor_degree` (`id`, `degree`, `detail`) VALUES
(1, 'MCM', 'Master of Clinical Medicine'),
(2, 'MD', 'Doctor of Medicine by research'),
(3, 'MM', 'Master of Medicine');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_slots`
--

CREATE TABLE `doctor_slots` (
  `id` bigint(100) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `date_id` int(11) NOT NULL,
  `slot_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='all doctor date with slots';

--
-- Dumping data for table `doctor_slots`
--

INSERT INTO `doctor_slots` (`id`, `doctor_id`, `date_id`, `slot_id`, `status`) VALUES
(19, 11, 2, 3, 0),
(20, 11, 2, 4, 0),
(21, 11, 2, 7, 0),
(22, 11, 2, 8, 0),
(23, 11, 3, 3, 0),
(24, 11, 3, 4, 0),
(25, 11, 3, 7, 0),
(26, 11, 3, 8, 0),
(27, 11, 4, 3, 0),
(28, 11, 4, 4, 0),
(29, 11, 4, 7, 0),
(30, 11, 4, 8, 0),
(31, 11, 5, 3, 0),
(32, 11, 5, 4, 0),
(33, 11, 5, 7, 0),
(34, 11, 5, 8, 0),
(35, 11, 6, 3, 0),
(36, 11, 6, 4, 0),
(37, 11, 6, 7, 0),
(38, 11, 6, 8, 0),
(39, 11, 7, 3, 0),
(40, 11, 7, 4, 0),
(41, 11, 7, 7, 0),
(42, 11, 7, 8, 0),
(43, 11, 8, 3, 0),
(44, 11, 8, 4, 0),
(45, 11, 8, 7, 0),
(46, 11, 8, 8, 0),
(47, 11, 9, 3, 0),
(48, 11, 9, 4, 0),
(49, 11, 9, 7, 0),
(50, 11, 9, 8, 0),
(51, 11, 10, 3, 0),
(52, 11, 10, 4, 0),
(53, 11, 10, 7, 0),
(54, 11, 10, 8, 0),
(55, 11, 11, 3, 0),
(56, 11, 11, 4, 0),
(57, 11, 11, 7, 0),
(58, 11, 11, 8, 0),
(59, 11, 12, 3, 0),
(60, 11, 12, 4, 0),
(61, 11, 12, 7, 0),
(62, 11, 12, 8, 0),
(63, 11, 13, 3, 0),
(64, 11, 13, 4, 0),
(65, 11, 13, 7, 0),
(66, 11, 13, 8, 0),
(67, 11, 14, 3, 0),
(68, 11, 14, 4, 0),
(69, 11, 14, 7, 0),
(70, 11, 14, 8, 0),
(71, 11, 15, 3, 0),
(72, 11, 15, 4, 0),
(73, 11, 15, 7, 0),
(74, 11, 15, 8, 0),
(75, 11, 16, 3, 0),
(76, 11, 16, 4, 0),
(77, 11, 16, 7, 0),
(78, 11, 16, 8, 0),
(79, 11, 17, 3, 0),
(80, 11, 17, 4, 0),
(81, 11, 17, 7, 0),
(82, 11, 17, 8, 0),
(83, 11, 18, 3, 0),
(84, 11, 18, 4, 0),
(85, 11, 18, 7, 0),
(86, 11, 18, 8, 0),
(87, 11, 19, 3, 0),
(88, 11, 19, 4, 0),
(89, 11, 19, 7, 0),
(90, 11, 19, 8, 0),
(91, 11, 20, 3, 0),
(92, 11, 20, 4, 0),
(93, 11, 20, 7, 0),
(94, 11, 20, 8, 0),
(95, 11, 21, 3, 0),
(96, 11, 21, 4, 0),
(97, 11, 21, 7, 0),
(98, 11, 21, 8, 0),
(99, 11, 22, 3, 0),
(100, 11, 22, 4, 0),
(101, 11, 22, 7, 0),
(102, 11, 22, 8, 0),
(103, 11, 23, 3, 0),
(104, 11, 23, 4, 0),
(105, 11, 23, 7, 0),
(106, 11, 23, 8, 0),
(107, 11, 24, 3, 0),
(108, 11, 24, 4, 0),
(109, 11, 24, 7, 0),
(110, 11, 24, 8, 0),
(111, 11, 25, 3, 0),
(112, 11, 25, 4, 0),
(113, 11, 25, 7, 0),
(114, 11, 25, 8, 0),
(115, 11, 26, 3, 0),
(116, 11, 26, 4, 0),
(117, 11, 26, 7, 0),
(118, 11, 26, 8, 0),
(119, 11, 27, 3, 0),
(120, 11, 27, 4, 0),
(121, 11, 27, 7, 0),
(122, 11, 27, 8, 0),
(123, 11, 28, 3, 0),
(124, 11, 28, 4, 0),
(125, 11, 28, 7, 0),
(126, 11, 28, 8, 0),
(127, 11, 29, 3, 0),
(128, 11, 29, 4, 0),
(129, 11, 29, 7, 0),
(130, 11, 29, 8, 0),
(131, 11, 30, 3, 0),
(132, 11, 30, 4, 0),
(133, 11, 30, 7, 0),
(134, 11, 30, 8, 0),
(135, 11, 31, 3, 0),
(136, 11, 31, 4, 0),
(137, 11, 31, 7, 0),
(138, 11, 31, 8, 0),
(157, 12, 1, 1, 0),
(158, 12, 1, 2, 0),
(159, 12, 1, 3, 0),
(160, 12, 1, 4, 0),
(161, 12, 1, 5, 0),
(162, 12, 1, 6, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doc_professional_info`
--

CREATE TABLE `doc_professional_info` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `speciality_id` tinyint(3) UNSIGNED NOT NULL,
  `degree_id` tinyint(3) UNSIGNED NOT NULL,
  `undergraduate_university` tinytext,
  `medical_school` mediumtext,
  `residency` mediumtext,
  `medical_license_number` varchar(45) DEFAULT NULL,
  `additional_info` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `doc_professional_info`
--

INSERT INTO `doc_professional_info` (`id`, `doctor_id`, `speciality_id`, `degree_id`, `undergraduate_university`, `medical_school`, `residency`, `medical_license_number`, `additional_info`) VALUES
(2, 9, 1, 1, 'test', 'abcd', 'xyz', 'hhh', 'doctor instruction'),
(5, 1, 2, 2, 'xyz', 'fff', 'ff', 'f', 'doctor instruction one'),
(6, 11, 4, 3, 'hello', 'fff', 'ff', 'f', 'doctor instruction two'),
(10, 10, 3, 3, 'abc', 'fff', 'ff', 'f', 'doctor instruction three'),
(15, 12, 5, 1, 'test', 'fff', 'ff', 'f', 'ff'),
(16, 13, 1, 1, 'test', 'fff', 'ff', 'f', 'ff');

-- --------------------------------------------------------

--
-- Table structure for table `error_success_message`
--

CREATE TABLE `error_success_message` (
  `id` int(11) NOT NULL,
  `code` int(10) NOT NULL,
  `message` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `type` varchar(45) DEFAULT NULL,
  `question` varchar(90) DEFAULT NULL,
  `answer` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`id`, `type`, `question`, `answer`) VALUES
(1, NULL, 'What is DOCMD ?', 'Nulla pretiumod ovelta'),
(2, NULL, 'How do I get started as a doctor ar DOCMD', 'Nulla pretiumod\novelta');

-- --------------------------------------------------------

--
-- Table structure for table `hour_list`
--

CREATE TABLE `hour_list` (
  `id` int(11) NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hour_list`
--

INSERT INTO `hour_list` (`id`, `start_time`, `end_time`) VALUES
(1, '10:00:00', '10:30:00'),
(2, '10:30:00', '11:00:00'),
(3, '11:00:00', '11:30:00'),
(4, '11:30:00', '12:00:00'),
(5, '14:00:00', '14:30:00'),
(6, '14:30:00', '15:00:00'),
(7, '12:00:00', '12:30:00'),
(8, '12:30:00', '13:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `language`
--

CREATE TABLE `language` (
  `language_id` tinyint(3) UNSIGNED NOT NULL,
  `name` char(20) NOT NULL,
  `sp_name` varchar(30) NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `language`
--

INSERT INTO `language` (`language_id`, `name`, `sp_name`, `last_update`) VALUES
(1, 'English', '', '2018-04-18 12:25:22'),
(2, 'Spanish', '', '2018-04-18 12:25:22'),
(3, 'English and Spanish', '', '2018-04-18 12:25:57');

-- --------------------------------------------------------

--
-- Table structure for table `notification_records`
--

CREATE TABLE `notification_records` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `name` varchar(45) NOT NULL,
  `profile_url` varchar(255) DEFAULT NULL,
  `type` varchar(16) NOT NULL COMMENT 'provider_plan_type',
  `notify_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification_records`
--

INSERT INTO `notification_records` (`id`, `appointment_id`, `name`, `profile_url`, `type`, `notify_time`) VALUES
(1, 8, 'dkone khan', NULL, 'messages', '2018-04-23 05:24:19'),
(4, 13, 'amey brother lee', 'http://localhost/docmd/assets/users/profile/1528569393MEdHh6GP.png', 'messages', '2018-04-23 06:26:00'),
(7, 16, 'cathy lee', NULL, 'Video', '2018-04-24 03:32:55'),
(9, 26, 'bablu khan', NULL, 'messages', '2018-04-24 03:49:32'),
(12, 33, 'amey brother lee', 'http://localhost/docmd/assets/users/profile/1528569393MEdHh6GP.png', 'messages', '2018-04-25 01:13:49');

-- --------------------------------------------------------

--
-- Table structure for table `patient_address`
--

CREATE TABLE `patient_address` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `address_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='All users and patients address map';

--
-- Dumping data for table `patient_address`
--

INSERT INTO `patient_address` (`id`, `patient_id`, `address_id`) VALUES
(32, 74, 60),
(33, 75, 61),
(34, 76, 70),
(35, 77, 71),
(44, 88, 59);

-- --------------------------------------------------------

--
-- Table structure for table `patient_formacy_list`
--

CREATE TABLE `patient_formacy_list` (
  `user_id` int(11) NOT NULL,
  `pharmacy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `patient_info`
--

CREATE TABLE `patient_info` (
  `id` int(11) NOT NULL,
  `first_name` varchar(45) DEFAULT NULL,
  `last_name` varchar(45) DEFAULT NULL,
  `profile_url` varchar(255) DEFAULT NULL,
  `profile_image` varchar(40) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `provider` varchar(10) DEFAULT NULL,
  `member_id` varchar(16) DEFAULT NULL,
  `ins_group` text,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `last_update` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Users or Patients basic information';

--
-- Dumping data for table `patient_info`
--

INSERT INTO `patient_info` (`id`, `first_name`, `last_name`, `profile_url`, `profile_image`, `date_of_birth`, `gender`, `provider`, `member_id`, `ins_group`, `is_deleted`, `user_id`, `created_date`, `last_update`) VALUES
(16, 'harish', 'khan', 'http://localhost/docmd/assets/users/profile/15513320218T9tk7Fl.png', '15513320218T9tk7Fl.png', '1998-08-12', 'male', NULL, NULL, NULL, NULL, 1, NULL, '2018-02-23 11:13:22'),
(19, 'aamir', 'khan', 'http://18.219.252.10/docmd/assets/users/profile/1529249903XTQNHhDp.PNG', '1529249903XTQNHhDp.PNG', '2018-10-08', 'male', NULL, NULL, NULL, NULL, NULL, NULL, '2018-02-26 07:10:43'),
(22, 'zaheer', 'khan', 'http://localhost/docmd/assets/users/profile/1528569393MEdHh6GP.png', '1523081152xLlAZE7J.png', '1998-08-12', 'female', NULL, NULL, NULL, NULL, 99, '2018-03-05 10:20:25', '2018-03-05 10:20:25'),
(23, 'surendra', 'kumar', NULL, '', '2018-10-08', 'male', NULL, NULL, NULL, NULL, 18, '2018-03-06 09:27:05', '2018-03-06 09:27:05'),
(73, 'aamir', 'khan', 'http://18.219.252.10/docmd/assets/users/profile/1523081152xLlAZE7J.png', '1523081152xLlAZE7J.png', '1998-08-12', 'male', NULL, NULL, NULL, NULL, 99, '2018-03-05 10:20:25', '2018-03-05 10:20:25'),
(74, 'cathy', 'lee', NULL, '', '1992-10-08', 'male', NULL, NULL, NULL, NULL, 18, '2018-03-12 08:16:21', '2018-03-12 08:16:21'),
(75, 'james brother', 'lee', NULL, '', '1998-10-08', 'male', NULL, NULL, NULL, NULL, 18, '2018-03-12 08:18:10', '2018-03-12 08:18:10'),
(76, 'bablu', 'khan', NULL, '', '1985-10-08', 'male', 'danish', '32433', 'danvd', NULL, 14, '2018-03-14 10:45:14', '2018-03-14 05:15:14'),
(77, 'amey brother', 'lee', 'http://localhost/docmd/assets/users/profile/1528569393MEdHh6GP.png', '1528569393MEdHh6GP.png', '1990-10-08', 'female', NULL, NULL, NULL, NULL, 14, '2018-03-14 10:46:34', '2018-03-14 05:16:34'),
(78, 'bablu', 'khan', NULL, '', '1985-10-08', 'male', 'danish', '32433', 'danvd', NULL, 14, '2018-03-14 10:47:05', '2018-03-14 05:17:05'),
(87, 'aamir', 'khan', NULL, '', '1980-10-08', 'male', 'testye', '1234', NULL, NULL, 18, '2018-03-20 04:21:58', '2018-03-20 10:51:58'),
(88, 'dkone', 'khan', NULL, '', '1980-10-08', 'male', 'HP1234', '1234', 'ghfgh', NULL, 100, '2018-04-09 11:02:17', '2018-04-09 05:32:17');

-- --------------------------------------------------------

--
-- Table structure for table `pharmacies`
--

CREATE TABLE `pharmacies` (
  `id` smallint(6) NOT NULL,
  `pharmacy_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(40) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `address` tinytext NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longtitude` decimal(10,7) DEFAULT NULL,
  `pharmacy_img` varchar(100) DEFAULT NULL,
  `pharmacy_image_url` varchar(255) DEFAULT NULL,
  `is_blocked` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pharmacies`
--

INSERT INTO `pharmacies` (`id`, `pharmacy_name`, `phone`, `email`, `city`, `state`, `zip`, `address`, `start_time`, `end_time`, `latitude`, `longtitude`, `pharmacy_img`, `pharmacy_image_url`, `is_blocked`, `created_at`) VALUES
(1, 'CVS Corporations', '12345678900', 'pharmacyedit@gmail.com', 'Woonsocket', 'RIII', '12345678', '1 CVS Drive, Woonsocket, Rhode Island, United States', '12:10:00', '13:55:00', '42.0029000', '71.5148000', '1534512453mzVBosd0.png', 'http://localhost/docmd/assets/admin/img/pharmacy/1534512453mzVBosd0.png', 1, '2018-04-11 17:28:31'),
(2, 'VS Corporation', '1234567890', 'pharmacy1234@gmail.com', 'Woonsocket', 'RI', '3214567891', '1 CVS Drive, Woonsocket, Rhode Island, United States', '10:00:00', '04:00:00', '42.0029000', '71.5148000', '', '', 1, '2018-04-11 17:28:31'),
(3, 'Walgreens', '0117654321', 'walgreens@gmail.com', 'Chicago', 'Chicago', '2345611', '1901; 117 years agoChicago, Illinois, U.S.', '02:07:00', '06:11:00', NULL, NULL, NULL, NULL, 0, '2018-04-11 18:40:23'),
(4, 'Kroger', '0117654321', 'Kroger@gmail.com', 'Cincinnati', 'Cincinnati', '2345611', '1883; 135 years ago\r\nCincinnati, Ohio, U.S.', '03:07:00', '06:11:00', NULL, NULL, NULL, NULL, 0, '2018-04-11 18:40:23'),
(6, 'Costco', '1234567890', 'costco@gmail.com', 'California', 'Washington', '123456', 'Issaquah, Washington, United States', '11:05:00', '01:05:00', NULL, NULL, NULL, NULL, 0, '2018-04-12 17:03:46'),
(7, 'Publix', '1234567890', 'Publix@gmail.com', 'Lakelandd', 'Florida', '12345622', 'Lakeland, Florida, U.S.', '01:10:00', '12:20:00', NULL, NULL, '1547428389z8mKDIhl.png', 'http://localhost/docmd/assets/admin/img/pharmacy/1547428389z8mKDIhl.png', 1, '2018-04-12 17:50:59'),
(13, 'testr', '1234567890', 'admin@gmail.com', 'test city', 'test', 'dsfds4344', 'sfdf', '11:05:00', '11:55:00', NULL, NULL, '1549505621OrALNcS1.png', 'http://localhost/docmd/assets/admin/img/pharmacy/1549505621OrALNcS1.png', 1, '2018-04-13 11:17:53');

-- --------------------------------------------------------

--
-- Table structure for table `prescriptions`
--

CREATE TABLE `prescriptions` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `symptom_id` int(11) DEFAULT NULL,
  `prescriptions` varchar(255) DEFAULT NULL,
  `visit_date` date DEFAULT NULL,
  `visit_type` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Users or Patients prescriptions given by the doctor';

--
-- Dumping data for table `prescriptions`
--

INSERT INTO `prescriptions` (`id`, `patient_id`, `doctor_id`, `symptom_id`, `prescriptions`, `visit_date`, `visit_type`) VALUES
(1, 88, 11, 2, 'New medicine ', '2018-04-24', 'message');

-- --------------------------------------------------------

--
-- Table structure for table `provider_plan`
--

CREATE TABLE `provider_plan` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `title` varchar(30) DEFAULT NULL,
  `description` text,
  `amount` float DEFAULT NULL,
  `type` enum('message','audio','video','') NOT NULL,
  `is_recommended` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `provider_plan`
--

INSERT INTO `provider_plan` (`id`, `title`, `description`, `amount`, `type`, `is_recommended`) VALUES
(1, 'messages', 'This is messages system', 10, 'message', '1'),
(2, 'Audio', 'This is audio call', 10, 'message', '1'),
(3, 'Video', 'This is video Call', 10, 'message', '0');

-- --------------------------------------------------------

--
-- Table structure for table `rating_review`
--

CREATE TABLE `rating_review` (
  `id` int(11) NOT NULL,
  `who_rate` enum('patient','doctor') NOT NULL,
  `review_given_by_id` int(11) NOT NULL,
  `review_given_to_id` int(11) NOT NULL,
  `rating` float(2,1) NOT NULL,
  `comment` tinytext,
  `created_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `severity_of_symptoms`
--

CREATE TABLE `severity_of_symptoms` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `severity_of_symptoms`
--

INSERT INTO `severity_of_symptoms` (`id`, `name`) VALUES
(1, 'Acute'),
(2, 'Constant'),
(3, 'Intermittent'),
(4, 'Chronic'),
(5, 'Not Sure');

-- --------------------------------------------------------

--
-- Table structure for table `spacility`
--

CREATE TABLE `spacility` (
  `id` tinyint(3) UNSIGNED NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `description` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `spacility`
--

INSERT INTO `spacility` (`id`, `name`, `description`) VALUES
(1, 'Alternative Health', 'Alternative Health'),
(2, 'Diet & Nutrition', 'Diet &amp; Nutrition'),
(3, 'Therapyh', 'Therapyh'),
(4, 'Medical Adults', 'Medical Adults'),
(5, 'Medical Children', 'Medical Children');

-- --------------------------------------------------------

--
-- Table structure for table `symptom`
--

CREATE TABLE `symptom` (
  `id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `additional_info` tinytext,
  `spn_name` varchar(45) DEFAULT NULL,
  `spn_additional_info` tinytext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `symptom`
--

INSERT INTO `symptom` (`id`, `name`, `additional_info`, `spn_name`, `spn_additional_info`) VALUES
(1, 'Whooping cough', 'Tos ferina', 'Tos ferina', ''),
(2, 'Medication-related cough', 'Tos relacionada con medicamentos', 'Tos relacionada con medicamentos', ''),
(3, 'Chronic cough', '', 'Tos crónica', ''),
(5, 'Testing', 'This is testingg', 'Testing Spanish', 'This is Spanish additional info');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(80) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `is_email_verified` tinyint(1) DEFAULT '0' COMMENT '0=>unverified 1=>verified',
  `is_phone_verified` tinyint(1) DEFAULT '0' COMMENT '0=>unverified 1=>verified',
  `is_blocked` tinyint(1) DEFAULT '0' COMMENT '1=>block,0=>unblock',
  `is_read_consent_care` tinyint(1) NOT NULL DEFAULT '0',
  `access_token` varchar(255) NOT NULL,
  `device_token` varchar(255) DEFAULT NULL,
  `email_verification_code` tinytext,
  `created_date` datetime DEFAULT NULL,
  `last_update_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='All users and patient';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `phone`, `password`, `is_email_verified`, `is_phone_verified`, `is_blocked`, `is_read_consent_care`, `access_token`, `device_token`, `email_verification_code`, `created_date`, `last_update_date`) VALUES
(1, 'saurabh@chromeinfotech.com', '12305078144414', '1098a0cc04be483cbc6cac21f8ce9573', 1, 1, 0, 0, '0af7e09861528380e39c07ae226c5a52', 'AAAA6OrRkZ8:APA91bHCZBvfLdi5w-SKyvq6Mn0e-HGY_V0uVjxd4baS95bkwh1WSSZ1UTi_Oxrvn88gzcjswCMc4X5KwNiAjijOpgBamcQd9T7s48m2aCFrYo7SQ96AqEmXfYOamT4fq4arJTY4byay', '3ip9hZJhAxC90cDbNtB68dF2GMl8yuYUtXHj8mSrc9LZ64RQ+1sKc2zfU00roLA7dSrJkQXqBrk9H8Y0HMc0XA==', '2018-02-23 03:50:08', '2018-02-23 10:20:08'),
(8, 'dsaifi007@gmail.com', '12305078144410', '25d55ad283aa400af464c76d713c07ad', 1, 1, 1, 0, '0af7e09861528380e39c07ae226c5a51', 'AAAA6OrRkZ8:APA91bHCZBvfLdi5w-SKyvq6Mn0e-HGY_V0uVjxd4baS95bkwh1WSSZ1UTi_Oxrvn88gzcjswCMc4X5KwNiAjijOpgBamcQd9T7s48m2aCFrYo7SQ96AqEmXfYOamT4fq4arJTY4byay', 'goGujzC0jmNoZsCsAIDC6kuEcHM7kufU2Rn3OcgSJlDX2kbM9jL4I8mliBzL3KbtGoPUvPG7LvX77U0q+7bQ4A==', '2018-02-23 03:50:08', '2018-02-23 10:20:08'),
(14, 'kumars@chromeinfotech.com', '+0264814141842', 'abbbd7bf4b2f26e7e952df836f14e008', 1, 1, 0, 1, 'f91913b1c3209d24a9a840a786433a76', 'AAAA6OrRkZ8:APA91bHCZBvfLdi5w-SKyvq6Mn0e-HGY_V0uVjxd4baS95bkwh1WSSZ1UTi_Oxrvn88gzcjswCMc4X5KwNiAjijOpgBamcQd9T7s48m2aCFrYo7SQ96AqEmXfYOamT4fq4arJTY4byay', 'ZGFuaXNoa0BjaHJvbWVpbmZvdGVjaC5jb20=', '2018-03-05 10:15:30', '2018-03-05 10:15:30'),
(18, 'danishk@chromeinfotech.com', '+0263814141842', '2f29722c679a5c12c19a0db5bf8d5568', 1, 1, 0, 0, 'b6f56a1a5c4f5c0d4b798a80bc3d439e', 'AAAA6OrRkZ8:APA91bHCZBvfLdi5w-SKyvq6Mn0e-HGY_V0uVjxd4baS95bkwh1WSSZ1UTi_Oxrvn88gzcjswCMc4X5KwNiAjijOpgBamcQd9T7s48m2aCFrYo7SQ96AqEmXfYOamT4fq4arJTY4byay', 'ZGFuaXNoa0BjaHJvbWVpbmZvdGVjaC5jb20=', '2018-03-06 08:22:56', '2018-03-06 08:22:56'),
(99, 'danishmaint1@gmail.com', '+0110452781790', '3d966cb729c865e73edc3280a9e2ee2f', 0, 0, 0, 0, 'd65d4172d4212c0bbaebf9786d27bf70', 'AAAA6OrRkZ8:APA91bHCZBvfLdi5w-SKyvq6Mn0e-HGY_V0uVjxd4baS95bkwh1WSSZ1UTi_Oxrvn88gzcjswCMc4X5KwNiAjijOpgBamcQd9T7s48m2aCFrYo7SQ96AqEmXfYOamT4fq4arJTY4byay', NULL, '2018-03-09 08:57:39', '2018-03-09 08:57:39'),
(100, 'dangishmaint2@gmail.com', '01104527810903456789', '3d966cb729c865e73edc3280a9e2ee2f', 0, 0, 0, 0, '2f142856dfaf01a53448a40c6376daa6', 'AAAA6OrRkZ8:APA91bHCZBvfLdi5w-SKyvq6Mn0e-HGY_V0uVjxd4baS95bkwh1WSSZ1UTi_Oxrvn88gzcjswCMc4X5KwNiAjijOpgBamcQd9T7s48m2aCFrYo7SQ96AqEmXfYOamT4fq4arJTY4byay', 'ZGFuZ2lzaG1haW50QGdtYWlsLmNvbQ==', '2018-04-09 10:59:59', '2018-04-09 05:29:59'),
(101, 'dangishmaint@gmail.com', '01104527810903456789', '3d966cb729c865e73edc3280a9e2ee2f', 0, 0, 0, 0, '6cd2dd194972fc341678aa28423cfa28', 'AAAA6OrRkZ8:APA91bHCZBvfLdi5w-SKyvq6Mn0e-HGY_V0uVjxd4baS95bkwh1WSSZ1UTi_Oxrvn88gzcjswCMc4X5KwNiAjijOpgBamcQd9T7s48m2aCFrYo7SQ96AqEmXfYOamT4fq4arJTY4byay', 'ZGFuZ2lzaG1haW50QGdtYWlsLmNvbQ==', '2018-04-20 12:01:43', '2018-04-20 06:31:43');

-- --------------------------------------------------------

--
-- Table structure for table `users_messages`
--

CREATE TABLE `users_messages` (
  `id` int(11) NOT NULL,
  `user_from_id` int(11) NOT NULL,
  `user_to_id` int(11) NOT NULL,
  `messages` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='All users chatting conversation ';

-- --------------------------------------------------------

--
-- Table structure for table `user_medical_profile`
--

CREATE TABLE `user_medical_profile` (
  `id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL COMMENT 'patient_id',
  `medications` tinytext,
  `allergies` tinytext,
  `past_medical_history` tinytext,
  `social_history` tinytext,
  `family_history` tinytext,
  `created_at` date NOT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Users or patients medical problems';

--
-- Dumping data for table `user_medical_profile`
--

INSERT INTO `user_medical_profile` (`id`, `patient_id`, `medications`, `allergies`, `past_medical_history`, `social_history`, `family_history`, `created_at`, `updated_at`) VALUES
(22, 87, 'this is david medications', 'This is david allergies', 'david', 'david', 'david', '2018-03-20', '2018-03-20 10:51:58'),
(24, 78, 'dsds', 'This is james allergies', '', 'ss', 'ddd', '0000-00-00', '2018-03-28 06:00:02'),
(25, 76, 'dsds', 'This is james allergies', '', 'ss', 'ddd', '0000-00-00', '2018-03-28 06:01:36'),
(26, 88, 'this is d medications', 'This is d allergies', 'david', 'new', 'one', '2018-04-09', '2018-04-09 05:32:18');

-- --------------------------------------------------------

--
-- Table structure for table `user_otp`
--

CREATE TABLE `user_otp` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `otp_number` char(4) NOT NULL,
  `expire_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_otp`
--

INSERT INTO `user_otp` (`id`, `user_id`, `doctor_id`, `otp_number`, `expire_time`) VALUES
(1, 10, NULL, '4856', '2018-03-15 13:14:46'),
(3, 1, NULL, '4266', '2018-03-15 13:16:00'),
(18, NULL, 11, '3076', '2018-03-19 13:30:59'),
(20, 102, NULL, '8794', '2018-03-19 16:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `user_patient`
--

CREATE TABLE `user_patient` (
  `user_id` int(11) NOT NULL DEFAULT '0',
  `patient_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='User mappping with patients';

--
-- Dumping data for table `user_patient`
--

INSERT INTO `user_patient` (`user_id`, `patient_id`) VALUES
(1, 16),
(99, 22),
(18, 23),
(8, 74),
(14, 76),
(100, 88);

-- --------------------------------------------------------

--
-- Structure for view `all_appointment`
--
DROP TABLE IF EXISTS `all_appointment`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `all_appointment`  AS  select `a`.`patient_id` AS `patient_id`,`a`.`doctor_id` AS `doctor_id`,`a`.`id` AS `appointment_id`,group_concat(`c`.`name` separator ',') AS `symptoms`,concat(`d`.`first_name`,' ',`d`.`last_name`) AS `name`,floor(((to_days(curdate()) - to_days(`d`.`date_of_birth`)) / 365.25)) AS `age`,`d`.`gender` AS `gender`,`a`.`patient_availability_date_and_time` AS `patient_availability_date_and_time`,`e`.`title` AS `type`,`a`.`status` AS `status` from ((((`appointment` `a` join `appointment_symptom` `b` on((`a`.`id` = `b`.`appointment_id`))) join `symptom` `c` on((`c`.`id` = `b`.`symptom_id`))) left join `patient_info` `d` on((`a`.`patient_id` = `d`.`id`))) join `provider_plan` `e` on((`e`.`id` = `a`.`treatment_provider_plan_id`))) group by `b`.`appointment_id` ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_appointment_doctor_idx` (`doctor_id`,`patient_id`),
  ADD KEY `fk_appointment_spacility_idx` (`doc_speciality_id`),
  ADD KEY `fk_appointment_plan_idx` (`treatment_provider_plan_id`),
  ADD KEY `fk_patient_id` (`patient_id`) USING BTREE,
  ADD KEY `status` (`status`);

--
-- Indexes for table `appointment_status`
--
ALTER TABLE `appointment_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment_symptom`
--
ALTER TABLE `appointment_symptom`
  ADD KEY `fk_appointment_symptom_appointment_idx` (`appointment_id`),
  ADD KEY `fk_appointment_symptom_idx` (`symptom_id`);

--
-- Indexes for table `consent_care`
--
ALTER TABLE `consent_care`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`content_id`);

--
-- Indexes for table `date_availability_list`
--
ALTER TABLE `date_availability_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `date_available` (`date_available`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `access_token` (`access_token`),
  ADD KEY `language_id` (`language_id`);

--
-- Indexes for table `doctor_address`
--
ALTER TABLE `doctor_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_doctor_address_1_idx` (`doctor_id`),
  ADD KEY `fk_doctor_address_2_idx` (`address_id`);

--
-- Indexes for table `doctor_availability_list`
--
ALTER TABLE `doctor_availability_list`
  ADD PRIMARY KEY (`doctor_availability_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `doctor_degree`
--
ALTER TABLE `doctor_degree`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_slots`
--
ALTER TABLE `doctor_slots`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `date_id` (`date_id`),
  ADD KEY `slot_id` (`slot_id`);

--
-- Indexes for table `doc_professional_info`
--
ALTER TABLE `doc_professional_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_doc_professional_info_doctor_idx` (`doctor_id`),
  ADD KEY `speciality_id` (`speciality_id`),
  ADD KEY `degree_id` (`degree_id`);

--
-- Indexes for table `error_success_message`
--
ALTER TABLE `error_success_message`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hour_list`
--
ALTER TABLE `hour_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`language_id`);

--
-- Indexes for table `notification_records`
--
ALTER TABLE `notification_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `appointment_id` (`appointment_id`);

--
-- Indexes for table `patient_address`
--
ALTER TABLE `patient_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_patient_address_2_idx` (`address_id`),
  ADD KEY `fk_user_id_idx` (`patient_id`) USING BTREE;

--
-- Indexes for table `patient_formacy_list`
--
ALTER TABLE `patient_formacy_list`
  ADD KEY `fk_patient_formacy_list_patient_idx` (`user_id`);

--
-- Indexes for table `patient_info`
--
ALTER TABLE `patient_info`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_paitent_user_idx` (`user_id`);

--
-- Indexes for table `pharmacies`
--
ALTER TABLE `pharmacies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`),
  ADD KEY `state` (`state`),
  ADD KEY `city` (`city`);

--
-- Indexes for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_prescriptions_patient_idx` (`patient_id`),
  ADD KEY `fk_prescriptions_doctor_idx` (`doctor_id`),
  ADD KEY `fk_prescriptions_symptom_idx` (`symptom_id`);

--
-- Indexes for table `provider_plan`
--
ALTER TABLE `provider_plan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating_review`
--
ALTER TABLE `rating_review`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `severity_of_symptoms`
--
ALTER TABLE `severity_of_symptoms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `spacility`
--
ALTER TABLE `spacility`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `symptom`
--
ALTER TABLE `symptom`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `access_token` (`access_token`);

--
-- Indexes for table `users_messages`
--
ALTER TABLE `users_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_from_id_idx` (`user_from_id`),
  ADD KEY `fk_user_to_id_idx` (`user_to_id`) USING BTREE;

--
-- Indexes for table `user_medical_profile`
--
ALTER TABLE `user_medical_profile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_medical_profile_patient_idx` (`patient_id`);

--
-- Indexes for table `user_otp`
--
ALTER TABLE `user_otp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `user_patient`
--
ALTER TABLE `user_patient`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_user_patient_user_idx` (`user_id`),
  ADD KEY `fk_user_patient_patient_idx` (`patient_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `appointment_status`
--
ALTER TABLE `appointment_status`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `consent_care`
--
ALTER TABLE `consent_care`
  MODIFY `id` tinyint(1) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `date_availability_list`
--
ALTER TABLE `date_availability_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `doctor_address`
--
ALTER TABLE `doctor_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `doctor_availability_list`
--
ALTER TABLE `doctor_availability_list`
  MODIFY `doctor_availability_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;
--
-- AUTO_INCREMENT for table `doctor_degree`
--
ALTER TABLE `doctor_degree`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `doctor_slots`
--
ALTER TABLE `doctor_slots`
  MODIFY `id` bigint(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=163;
--
-- AUTO_INCREMENT for table `doc_professional_info`
--
ALTER TABLE `doc_professional_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `error_success_message`
--
ALTER TABLE `error_success_message`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `hour_list`
--
ALTER TABLE `hour_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `language`
--
ALTER TABLE `language`
  MODIFY `language_id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `notification_records`
--
ALTER TABLE `notification_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `patient_address`
--
ALTER TABLE `patient_address`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
--
-- AUTO_INCREMENT for table `patient_info`
--
ALTER TABLE `patient_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=89;
--
-- AUTO_INCREMENT for table `pharmacies`
--
ALTER TABLE `pharmacies`
  MODIFY `id` smallint(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `prescriptions`
--
ALTER TABLE `prescriptions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `provider_plan`
--
ALTER TABLE `provider_plan`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `rating_review`
--
ALTER TABLE `rating_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `severity_of_symptoms`
--
ALTER TABLE `severity_of_symptoms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `spacility`
--
ALTER TABLE `spacility`
  MODIFY `id` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `symptom`
--
ALTER TABLE `symptom`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
--
-- AUTO_INCREMENT for table `users_messages`
--
ALTER TABLE `users_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user_medical_profile`
--
ALTER TABLE `user_medical_profile`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `user_otp`
--
ALTER TABLE `user_otp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_5` FOREIGN KEY (`patient_id`) REFERENCES `patient_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_ibfk_6` FOREIGN KEY (`doc_speciality_id`) REFERENCES `spacility` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_ibfk_7` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_ibfk_8` FOREIGN KEY (`treatment_provider_plan_id`) REFERENCES `provider_plan` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_ibfk_9` FOREIGN KEY (`status`) REFERENCES `appointment_status` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `appointment_symptom`
--
ALTER TABLE `appointment_symptom`
  ADD CONSTRAINT `appointment_symptom_ibfk_3` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `appointment_symptom_ibfk_4` FOREIGN KEY (`symptom_id`) REFERENCES `symptom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctors`
--
ALTER TABLE `doctors`
  ADD CONSTRAINT `doctors_ibfk_1` FOREIGN KEY (`language_id`) REFERENCES `language` (`language_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor_address`
--
ALTER TABLE `doctor_address`
  ADD CONSTRAINT `doctor_address_ibfk_2` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doctor_address_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor_availability_list`
--
ALTER TABLE `doctor_availability_list`
  ADD CONSTRAINT `doctor_availability_list_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doctor_slots`
--
ALTER TABLE `doctor_slots`
  ADD CONSTRAINT `doctor_slots_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doctor_slots_ibfk_2` FOREIGN KEY (`date_id`) REFERENCES `date_availability_list` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doctor_slots_ibfk_3` FOREIGN KEY (`slot_id`) REFERENCES `hour_list` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `doc_professional_info`
--
ALTER TABLE `doc_professional_info`
  ADD CONSTRAINT `doc_professional_info_ibfk_1` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doc_professional_info_ibfk_2` FOREIGN KEY (`speciality_id`) REFERENCES `spacility` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `doc_professional_info_ibfk_3` FOREIGN KEY (`degree_id`) REFERENCES `doctor_degree` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notification_records`
--
ALTER TABLE `notification_records`
  ADD CONSTRAINT `notification_records_ibfk_1` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patient_address`
--
ALTER TABLE `patient_address`
  ADD CONSTRAINT `patient_address_ibfk_3` FOREIGN KEY (`address_id`) REFERENCES `address` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `patient_address_ibfk_4` FOREIGN KEY (`patient_id`) REFERENCES `patient_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patient_formacy_list`
--
ALTER TABLE `patient_formacy_list`
  ADD CONSTRAINT `patient_formacy_list_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `patient_info`
--
ALTER TABLE `patient_info`
  ADD CONSTRAINT `patient_info_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE SET NULL;

--
-- Constraints for table `prescriptions`
--
ALTER TABLE `prescriptions`
  ADD CONSTRAINT `prescriptions_ibfk_4` FOREIGN KEY (`patient_id`) REFERENCES `patient_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prescriptions_ibfk_5` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `prescriptions_ibfk_6` FOREIGN KEY (`symptom_id`) REFERENCES `symptom` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users_messages`
--
ALTER TABLE `users_messages`
  ADD CONSTRAINT `users_messages_ibfk_1` FOREIGN KEY (`user_from_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `users_messages_ibfk_2` FOREIGN KEY (`user_to_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_medical_profile`
--
ALTER TABLE `user_medical_profile`
  ADD CONSTRAINT `user_medical_profile_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patient_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_patient`
--
ALTER TABLE `user_patient`
  ADD CONSTRAINT `user_patient_ibfk_3` FOREIGN KEY (`patient_id`) REFERENCES `patient_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
